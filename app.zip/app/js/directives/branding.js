four51.app.directive('branding', function() {
    var obj = {
        restrict: 'E',
        templateUrl: 'partials/branding.html'
    }
    return obj;
});