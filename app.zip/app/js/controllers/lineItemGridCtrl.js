'use strict';

four51.app.controller('LineItemGridCtrl', function ($scope, Order) {

});
