'use strict';

var four51 = {};
four51.app = angular.module('451order', ['ngResource', 'ngRoute', 'ngAnimate', 'ngSanitize', 'ngCookies', 'ngTouch', 'ngGrid', 'ui.bootstrap', 'ui.date', 'ui.validate', 'ui.mask']);

